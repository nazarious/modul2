# MMI Demo project

Demo Project for MMI WS 24/25. We will use this project to apply theoretical knowledge (e.g. versioning via Git, Refactoring, Unit Tests, Usability Tests)
